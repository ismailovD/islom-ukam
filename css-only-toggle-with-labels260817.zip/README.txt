A Pen created at CodePen.io. You can find this one at https://codepen.io/designcouch/pen/EjyxVJ.

 Ok, so I've done these before but never been fully satisfied. This is a refinement of this pen: http://codepen.io/designcouch/pen/sDAvk, but not a true fork of it.